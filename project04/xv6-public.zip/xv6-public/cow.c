#include "types.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "x86.h"
#include "proc.h"
#include "spinlock.h"

struct run {
  struct run *next;
};

struct {
  struct spinlock lock;
  int use_lock;
  struct run *freelist;
} kmem;

char pgrefcnt[PHYSTOP/PGSIZE];

static pte_t *walkpgdir(pde_t *, const void *, int);

// Wrapper function for conuntfp.
int
sys_countfp(void)
{
  return countfp();
}

// Wrapper function for countvp.
int
sys_countvp(void)
{
  return countvp();
}

// Wrapper function for countpp.
int
sys_countpp(void)
{
  return countpp();
}

// Wrapper function for countptp.
int
sys_countptp(void)
{
  return countptp();
}

// System call for counting the total number of free pages in system.
int
countfp(void)
{
  int rv;
  struct run *r;

  rv = 0;
  r = kmem.freelist;

  while(r){
    rv++;
    r = r->next;
  }

  return rv;
}

// System call for counting the number of logical pages in this process's user momory.
int
countvp(void)
{
  char *a, *last;
  int rv;

  a = (char*)0;

  // PGSIZE와의 모듈러 연산 결과 값이 1 이상이라면 페이지 하나가 더 필요함.
  last = (char*)PGROUNDUP(myproc()->sz);
  rv = 0;

  for(;;){
    if(a >= last)
      break;
    rv++;
    a += PGSIZE;
  }
  return rv;
}

// System call for counting the nubmer of allocated physical pages.
int
countpp(void)
{
  char *a;
  pte_t *pte;
  int rv;
  
  a = (char*)0;
  rv = 0;

  for(;;){
    if((pte = walkpgdir(myproc()->pgdir, a, 0)) == 0)
      return -1;
    if(!(*pte & PTE_P))
      break;
    rv++;
    a += PGSIZE;
  }
  return rv;
}

// System call for counting the number of pages which allocated by this process's page table.
int
countptp(void)
{
  int i, rv;
  pde_t *pde, *pgdir;
  
  rv = 0;
  pgdir = myproc()->pgdir;

  for(i = 0; i < NPDENTRIES; i++){
    pde = &pgdir[i];
    if(*pde & PTE_P)
      rv++;
  }

  // Plus 1 for pgdir.
  return rv + 1;
}

// Increase refcnt by 1.
void
incr_refc(uint pa)
{
  if(kmem.use_lock)
    acquire(&kmem.lock);

  pgrefcnt[pa/PGSIZE]++;

  //cprintf("incr_refc: pid: %d, name: %s, pa: %x, refcnt: %d\n", myproc()->pid, 
  //  myproc()->name, pa, pgrefcnt[pa/PGSIZE]);

  if(kmem.use_lock)
    release(&kmem.lock);
}

// Decrease refcnt by 1.
void
decr_refc(uint pa)
{
  if(kmem.use_lock)
    acquire(&kmem.lock);

  pgrefcnt[pa/PGSIZE]--;

  if(kmem.use_lock)
    release(&kmem.lock);
}

// Return refcnt.
int
get_refc(uint pa)
{
  int rv;

  if(kmem.use_lock)
    acquire(&kmem.lock);

  rv = pgrefcnt[pa/PGSIZE];

  if(kmem.use_lock)
    release(&kmem.lock);
  
  return rv;
}

// Make copy of user memory.
void
CoW_handler(void)
{  
  uint va_pgflt;
  char *mem, *va;
  pte_t *pte;
  struct proc *p;
  
  // Read cr2 register to specify address that pgflt occurred.
  va_pgflt = rcr2();
  p = myproc();

  // round up을 하게 되면 위 페이지를 할당하게 됨. 따라서 round down. 
  va = (char*)PGROUNDDOWN(va_pgflt);
  
  if((pte = walkpgdir(p->pgdir, va, 0)) == 0){
    cprintf("Cow_handler: unexpected page fault\n");
    p->killed = 1;
    return;
  }

  //cprintf("Cow_handler: pid: %d, %x, ref: %d\n", p->pid, PTE_ADDR(*pte), get_refc(PTE_ADDR(*pte)));

  // 해당 물리 페이지를 가리키는 유일한 프로세스일 경우
  if(get_refc(PTE_ADDR(*pte)) == 1){
    //cprintf("CoW_handler: pid: %d, name: %s\n", p->pid, p->name);
    *pte |= PTE_W;
    lcr3(V2P(p->pgdir));
    return;
  }

  decr_refc(PTE_ADDR(*pte));

  mem = kalloc();
  if(mem == 0){
    cprintf("Cow_handler: kalloc failed\n");
    p->killed = 1;
    return;
  }

  memmove(mem, (char*)P2V(PTE_ADDR(*pte)), PGSIZE);
  *pte = V2P(mem) | PTE_FLAGS(*pte) | PTE_W;
  lcr3(V2P(p->pgdir));
}

// Return the address of the PTE in page table pgdir
// that corresponds to virtual address va.  If alloc!=0,
// create any required page table pages.
static pte_t *
walkpgdir(pde_t *pgdir, const void *va, int alloc)
{
  pde_t *pde;
  pte_t *pgtab;

  pde = &pgdir[PDX(va)];
  if(*pde & PTE_P){
    pgtab = (pte_t*)P2V(PTE_ADDR(*pde));
  } else {
    if(!alloc || (pgtab = (pte_t*)kalloc()) == 0)
      return 0;
    // Make sure all those PTE_P bits are zero.
    memset(pgtab, 0, PGSIZE);
    // The permissions here are overly generous, but they can
    // be further restricted by the permissions in the page table
    // entries, if necessary.
    *pde = V2P(pgtab) | PTE_P | PTE_W | PTE_U;
  }
  return &pgtab[PTX(va)];
}