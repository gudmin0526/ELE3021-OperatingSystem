#include "types.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "x86.h"
#include "proc.h"
#include "spinlock.h"

struct {
  struct spinlock lock;
  struct proc proc[NPROC];
} ptable;

extern void forkret(void);
extern void trapret(void);

static void wakeup1(void *);
static struct proc *alloclwp(void);

// Wrapper function for thread_create
int
sys_thread_create(void)
{
  thread_t *thread;
  void *(*start_routine)(void *);
  void *arg;

  if(argptr(0, (char**)&thread, 4) < 0)
    return -1;
  if(argptr(1, (char**)&start_routine, 4) < 0)
    return -1;
  if(argptr(2, (char**)&arg, 4) < 0)
    return -1;

  thread_create(thread, start_routine, arg);
  return 0;
}

// Wrapper function for thread_exit
int 
sys_thread_exit(void)
{
  void *retval;

  if(argptr(0, (char**)&retval, 4) < 0)
    return -1;

  thread_exit(retval);
  return 0;
}

// Wrapper function for thread_join
int 
sys_thread_join(void)
{
  thread_t thread;
  void **retval;

  if(argptr(0, (char**)&thread, 4) < 0)
    return -1;
  if(argptr(1, (char**)&retval, 4) < 0)
    return -1;

  thread_join(thread, retval);
  return 0;
}

// System call for creating thread.
int 
thread_create(thread_t *thread, void *(*start_routine)(void *), void *arg) 
{
  int i;
  uint sz, sp, ustack[2];
  struct proc *t, *lwp;
  struct proc *curproc = myproc();

  // Allocate lwp.
  if((lwp = alloclwp()) == 0)
    return -1;

  // Avoid remap conflict with growproc.
  acquire(&ptable.lock);

  // Allocate 2 pages of stack to lwp.
  sz = PGROUNDUP(curproc->sz);
  if((sz = allocuvm(curproc->pgdir, sz, sz + 2*PGSIZE)) == 0)
    goto bad;
  clearpteu(curproc->pgdir, (char*)(sz - 2*PGSIZE));
  curproc->sz = sz;
  sp = sz;
  
  // To share heap segment, We need to expand lwp's size.
  lwp->parent = curproc;
  for(t = ptable.proc; t < &ptable.proc[NPROC]; t++){
    if(t->tid == 0 || t->parent != curproc)
      continue;
    t->sz = curproc->sz;
  }
  
  // Just share main lwp's pgdir.
  lwp->pgdir = curproc->pgdir;  
  
  *lwp->tf = *curproc->tf;

  release(&ptable.lock);

  // Push arg to user stack.
  ustack[0] = 0xffffffff; // fake return PC
  ustack[1] = (uint)arg;

  sp -= 8;
  if(copyout(lwp->pgdir, sp, ustack, 8) < 0)
    goto bad;

  // Assign a start point and stack pointer.
  lwp->tf->eip = (uint)start_routine;
  lwp->tf->ebp = sp + 8;
  lwp->tf->esp = sp;

  // Just use main lwp's file descriptor table.
  for(i = 0; i < NOFILE; i++)
    if(curproc->ofile[i])
      lwp->ofile[i] = curproc->ofile[i];
  lwp->cwd = curproc->cwd;

  safestrcpy(lwp->name, curproc->name, sizeof(curproc->name));

  switchuvm(curproc);

  acquire(&ptable.lock);

  lwp->state = RUNNABLE;

  release(&ptable.lock);

  // Pass ID of lwp.
  *thread = lwp->tid;

  return 0;

bad:
  kfree(lwp->kstack);
  lwp->state = UNUSED;
  return -1;
}

// System call for exiting thread.
void 
thread_exit(void *retval)
{
  struct proc *lwp = myproc();

  acquire(&ptable.lock);

  // Main lwp might be sleeping in wait().
  wakeup1(lwp->parent);

  // Pass retval to thread_join().
  lwp->retval = retval;

  // Jump into the scheduler, never to return.
  lwp->state = ZOMBIE;
  sched();
  panic("zombie exit");
}

// System call for deallocating thread.
int 
thread_join(thread_t thread, void **retval)
{
  struct proc *lwp;
  int havekids;
  struct proc *curproc = myproc();
  
  acquire(&ptable.lock);

  for(;;){
    // Scan through table looking for exited lwp.
    havekids = 0;
    for(lwp = ptable.proc; lwp < &ptable.proc[NPROC]; lwp++){
      if(lwp->tid != thread || lwp->parent != curproc)
        continue;
      
      havekids = 1;
      if(lwp->state == ZOMBIE){
  
        dealloclwp(lwp);
        *retval = lwp->retval;

        release(&ptable.lock);

        return 0;
      }
    }

    // No point waiting if we don't have any childeren.
    if(!havekids || curproc->killed){
      release(&ptable.lock);
      return -1;
    }

    // Wait for thread to exit.
    sleep(curproc, &ptable.lock);
  }
}

// Allocate thread to process.
static struct proc*
alloclwp(void)
{
  struct proc *lwp;
  struct proc *curproc = myproc();
  char *sp;

  acquire(&ptable.lock);

  for(lwp = ptable.proc; lwp < &ptable.proc[NPROC]; lwp++)
    if(lwp->state == UNUSED)
      goto found;

  release(&ptable.lock);
  return 0;

found:
  lwp->state = EMBRYO;
  lwp->pid = curproc->pid;

  // Initialize lwp attribute.
  lwp->tid = ++curproc->num_lwp;

  release(&ptable.lock);

  // Allocate kernel stack.
  if((lwp->kstack = kalloc()) == 0){
    lwp->state = UNUSED;
    return 0;
  }
  sp = lwp->kstack + KSTACKSIZE;

  // Leave room for trap frame.
  sp -= sizeof *lwp->tf;
  lwp->tf = (struct trapframe*)sp;

  // Set up new context to start executing at forkret,
  // which returns to trapret.
  sp -= 4;
  *(uint*)sp = (uint)trapret;

  sp -= sizeof *lwp->context;
  lwp->context = (struct context*)sp;
  memset(lwp->context, 0, sizeof *lwp->context);
  lwp->context->eip = (uint)forkret;

  return lwp;
}

void
dealloclwp(struct proc *lwp)
{
  kfree(lwp->kstack);
  lwp->kstack = 0;
  lwp->pid = 0;
  lwp->parent->num_lwp--;
  lwp->parent = 0;
  lwp->pgdir = 0;
  lwp->name[0] = 0;
  lwp->killed = 0;
  lwp->tf = 0;
  lwp->context = 0;
  lwp->state = UNUSED;

  // Disconnect from open files.
  for(int fd = 0; fd < NOFILE; fd++){
    if(lwp->ofile[fd]){
      lwp->ofile[fd] = 0;
    }
  }
  lwp->cwd = 0;
}

//PAGEBREAK!
// Wake up all processes sleeping on chan.
// The ptable lock must be held.
static void
wakeup1(void *chan)
{
  struct proc *p;

  for(p = ptable.proc; p < &ptable.proc[NPROC]; p++)
    if(p->state == SLEEPING && p->chan == chan)
      p->state = RUNNABLE;
}
